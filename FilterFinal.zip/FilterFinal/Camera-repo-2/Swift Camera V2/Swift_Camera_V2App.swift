//
//  Swift_Camera_V2App.swift
//  Swift Camera V2
//
//  Created by Jam school  on 3/17/23.
//

import SwiftUI

@main
struct Swift_Camera_V2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
